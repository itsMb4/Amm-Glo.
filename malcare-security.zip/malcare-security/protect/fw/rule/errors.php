<?php
if (!defined('ABSPATH') && !defined('MCDATAPATH')) exit;

if (!class_exists('MCProtectRuleError_V555')) :
class MCProtectRuleError_V555 extends Exception {
//Root rule error class.
}
endif;
